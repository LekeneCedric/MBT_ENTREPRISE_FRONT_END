export interface Ioutillage 
{
    id?:number
    intitule?:string,
    id_entreprise?:number
}