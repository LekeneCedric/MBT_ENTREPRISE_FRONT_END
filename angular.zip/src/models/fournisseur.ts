export interface IFournisseur{
    id?:number,
    id_entreprise?:number,
    nom?:string,
    telephone?:string,
    adresse?:string,
    created_at ?:Date,
    updated_at ?:Date
}