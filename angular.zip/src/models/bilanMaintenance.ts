export interface IBilanMaintenance {
    
}