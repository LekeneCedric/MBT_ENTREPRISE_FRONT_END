export interface Iauth
{
    email_entreprise?:number,
    code_entreprise?:string,
    pseudo?:string,
    password?:string
}