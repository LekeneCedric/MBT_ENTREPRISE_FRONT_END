export interface Iplan_maintenance
{
    id_agence?:number,
    id_salle?:number,
    id_equipement?:number,
    date_deb?:Date,
    date_fin?:Date
}