export interface Ilog
{
    id_entreprise?:number,
    id_agent?:number,
    date?:any,
    action?:string,
    group?:string,
    user?:string,
    created_at?:Date
}