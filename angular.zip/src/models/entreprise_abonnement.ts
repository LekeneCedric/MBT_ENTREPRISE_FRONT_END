export interface IEntrepriseAbonnement{
    
}