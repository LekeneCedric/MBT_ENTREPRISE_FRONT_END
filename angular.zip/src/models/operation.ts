export interface Ioperation 
{
    id?:number
    intitule?:string,
    id_entreprise?:number
}