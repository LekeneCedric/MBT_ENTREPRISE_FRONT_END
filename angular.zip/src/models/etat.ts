export interface Ietat 
{
    id?:number
    intitule?:string,
    id_entreprise?:number
}