export interface Istatistic
{
    nb_agences?:number,
    nb_salle?:number,
    nb_agents?:number,
    nb_fournisseurs?:number
}