export interface ICategorie{
        id?: number,
        idparent: number,
        intitule:string,
        created_at?:Date,
        updated_at?: Date
}