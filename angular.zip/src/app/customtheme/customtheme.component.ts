import { Component } from '@angular/core';

@Component({
  selector: 'app-customtheme',
  templateUrl: './customtheme.component.html',
  styleUrls: ['./customtheme.component.scss']
})
export class CustomthemeComponent {

}
