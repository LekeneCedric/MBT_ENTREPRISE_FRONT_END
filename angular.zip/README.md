# MBT_ENTREPRISE_FRONT_END

Web platform allowing a client company to manage its equipment, agencies, agents, offices and maintenance

----

after cloning the project locally, move to the main directory to be able to perform all operations

# Installation

Project Node Version 

```
16.17.1
```
to install and initialize all project dependencies using the [npm]('https://www.npmjs.com/)  package manager

```
npm install 
```
Or if there are versions errors 

```
npm install --legacy-peer-deps
```

### After launching the backend project 

# Run Project

```
ng serve -o
```


